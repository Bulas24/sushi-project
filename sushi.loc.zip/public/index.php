<?php

require_once "../config/init.php";
require_once LIBS.'/functions.php';
require_once CONF.'/routes.php';

new \ishop\App();

<?php
    return [
    'admin_email' => 'arkad-plus@mail.ru',
        'shop_name' => 'Магазин доставки суши sushimarket.space',
        'pagination' => 50,
        'smtp_host' => 'smtp.yandex.ru',
        'smtp_port' => '465',
        'smtp_protocol' => 'SSL',
        'smtp_login' => 'para2017dd@yandex.ru',
        'smtp_password' => '19901990w',
        'img_width' => 550,
        'img_height' => 411,
        'img_brand_width' => 350,
        'img_brand_height' => 250,
        'gallery_width' => 700,
        'gallery_height' => 1000,
        'gallery_brand_width' => 1280,
        'gallery_brand_height' => 850,
        'ik_key' => 'gng6LlR8h6FUlzic',
        'ik_co_id' => '5d81bbf71ae1bdd0848b456a',

    ];

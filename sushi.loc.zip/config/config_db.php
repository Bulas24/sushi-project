<?php
    return [
      'dsn' => 'mysql:host=localhost;dbname=sushi;charset=utf8',
        'user' => 'root',
        'password' => '',
    ];